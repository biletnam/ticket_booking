<?php
$con=mysql_connect("localhost","root","root");
$db=mysql_select_db("arrismea_guj_soc",$con);
?>