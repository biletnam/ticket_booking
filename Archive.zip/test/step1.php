<html>


<body>

	
	<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
	
	<input type="hidden" name="cmd" value="_xclick">
	
	<input type="hidden" name="business" value="office@gujaratisocietycfl.com">
	
	<input type="hidden" name="item_name" value="Book Ticket - B2,B3,B4">
	
	<input type="hidden" name="item_number" value="112233">
	

	<input type="hidden" name="no_note" value="1">
	<input type="hidden" name="currency_code" value="USD">

	<input type="hidden" name="return" value="http://gujaratisocietycfl.arristosoft.com/ticketdemo/payment_success.php">

	<input type="text" class="input-text"  name="amount" value="0.05" />

	<input type="submit" value="Transfer Amount" />
		
	</form>

</body>

</html>